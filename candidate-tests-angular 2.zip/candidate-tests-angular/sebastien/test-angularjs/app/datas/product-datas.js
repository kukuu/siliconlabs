[
    {
        "category": "Girls",
        "subcat": "5-7 years",
        "item": "Sleeve Leotard",
        "price": "22.95",
        "uid": 1
    },
	 {
        "category": "Girls",
        "subcat": "5 - 7 years",
        "item": "Strap Camisole Skirted",
        "price": "25.00",
        "uid": 2
    },
	 {
        "category": "Girls",
        "subcat": "5 - 7 years",
        "item": "Soft Jersey Wrap Top",
        "price": "21.95",
        "uid": 3
    },
	 {
        "category": "Girls",
        "subcat": "5 - 7 years",
        "item": "Hooded Zip Front Jacket",
        "price": "24.95",
        "uid": 4
    },
    {
        "category": "Girls",
        "subcat": "8 - 12 years",
        "item": "Bead Front Skirted",
        "price": "24.95",
        "uid": 5
    },
	{
        "category": "Girls",
        "subcat": "8 - 12 years",
        "item": "Dot Mesh Tank Leotard",
        "price": "22.00",
        "uid": 6
    },
    {
        "category": "Girls",
        "subcat": "13 - 16",
        "item": "Back Ruffle Layered Short",
        "price": "16.95",
        "uid": 7
    },
	 {
        "category": "Girls",
        "subcat": "13 - 16",
        "item": "Terry Pant With Drawcord",
        "price": "24.95",
        "uid": 8
    },
	 {
        "category": "Girls",
        "subcat": "13 - 16",
        "item": "Embroidered Mesh Front",
        "price": "19.95",
        "uid": 9
    },
    {
        "category": "Boys",
        "subcat": "5 - 7 years",
        "item": "44444",
        "price": "??.00",
        "uid": 10
    },
    {
        "category": "Boys",
        "subcat": "8 -12 years",
        "item": "?????",
        "price": "??.00",
        "uid": 11
    },
    {
        "category": "Boys",
        "subcat": "13 - 16 years",
        "item": "???????/",
        "price": "??.50",
        "uid": 12
    },
    {
        "category": "younger",
        "subcat": "2 - 5 years",
        "item": "Sleeve Leotard",
        "price": "??.00",
        "uid": 13
    }
]