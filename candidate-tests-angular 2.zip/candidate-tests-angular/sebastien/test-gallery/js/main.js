/*
---
name: Gallery
description: Instantiate a new Gallery
...
*/
var Gallery = Gallery || {};

(function(global, doc, object, undefined) {

	"use strict";

	function getElmById(id) {
		return doc.getElementById(id);
	};

	function Gallery() {

		this.mainImage  = getElmById('largeImg');
		this.thumbnails = doc.querySelectorAll('.item');
		this.navPrev    = getElmById('nav-prev');
		this.navNext    = getElmById('nav-next');
		this.active     = 0;

		this.attachThumbEvents();
		this.attachNavEvents();

	};

	Gallery.prototype = {

		constructor : Gallery,

		loadImage: function(src) {
			this.mainImage.src = src;
		},

		toElement: function(index) {
			if(this.thumbnails[index]){
				this.loadImage(this.thumbnails[index].href); // load new image
			}
		},

		onThumbClick: function(index, e) {
			e.preventDefault(); // stop default event behavior
			this.active = index
			this.toElement(this.active);
		},

		attachThumbEvents: function() {
			for(var i = 0, l = this.thumbnails.length; i<l; i++){
				this.thumbnails[i].addEventListener('click', this.onThumbClick.bind(this, i));
			}
			// note: there is a better way here using delegation event on thumbs container but the goal was to use the minimum amount of JavaScript
		},

		attachNavEvents: function() {

			// previous button
			this.navPrev.addEventListener('click', function() {
				this.active--;
				if(this.active < 0){
					this.active = this.thumbnails.length-1;
				}
				this.toElement(this.active);
			}.bind(this) );

			// next button
			this.navNext.addEventListener('click', function() {
				this.active++;
				if(this.active >= this.thumbnails.length){
					this.active = 0;
				}
				this.toElement(this.active);
			}.bind(this) );

		}

	};

	new Gallery();


})(window, document, Gallery);