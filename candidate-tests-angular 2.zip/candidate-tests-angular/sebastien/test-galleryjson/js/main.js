/*
---
name: JSONGallery
description: Instantiate a new Gallery using JSON datas
...
*/
var JSONGallery = JSONGallery || {};

(function(global, doc, object, undefined) {

	"use strict";

	function getJSON(url, callback){

		var _xhr = null;
		
		if(global.XMLHttpRequest){
			_xhr = new XMLHttpRequest(); // IE7+, Firefox, Chrome, Opera, Safari
		}else{
			_xhr = new ActiveXObject("Microsoft.XMLHTTP"); // IE6, IE5
		}

		_xhr.onreadystatechange = function(){
			if (_xhr.readyState === 4){
				if(_xhr.status === 200){ // success
					if(callback){
						callback(JSON.parse(_xhr.responseText));
					}
				}
			}
		};
		
		_xhr.open('GET', url, true);
		_xhr.send();

	};

	function getElmById(id) {
		return doc.getElementById(id);
	};

	function JSONGallery(url) {

		this.mainImage  = getElmById('largeImg');
		this.navPrev    = getElmById('nav-prev');
		this.navNext    = getElmById('nav-next');
		this.thumbs     = getElmById('thumbs');
		this.active     = 0;

		// get datas first, inject thumbnails, then init gallery
		getJSON(url, function(datas) {
			this.injectThumbs(datas);
			this.initGallery();
		}.bind(this));

	};

	JSONGallery.prototype = {

		constructor : JSONGallery,

		getFragment: function(datas) {
			var _fragment = doc.createDocumentFragment();

			// for each item in datas, create a new link with an image
			for (var i = 0, l = datas.length; i < l; i++){

				var _link = doc.createElement('a');
				_link.href  = datas[i].large;
				_link.title = datas[i].title;
				_link.className = "item";
				_link.innerHTML = "<img src="+datas[i].thumb+" alt="+datas[i].title+">";

				_fragment.appendChild(_link);

			}

			return _fragment;
		},

		injectThumbs: function(datas) {
			var _fragment = this.getFragment(datas);
			this.thumbs.appendChild(_fragment);
		},

		initGallery: function() {
			this.thumbnails = doc.querySelectorAll('.item');
			this.attachThumbEvents();
			this.attachNavEvents();
		},

		loadImage: function(src) {
			this.mainImage.src = src;
		},

		toElement: function(index) {
			if(this.thumbnails[index]){
				this.loadImage(this.thumbnails[index].href); // load new image
			}
		},

		onThumbClick: function(index, e) {
			e.preventDefault(); // stop default event behavior
			this.active = index
			this.toElement(this.active);
		},

		attachThumbEvents: function() {
			for(var i = 0, l = this.thumbnails.length; i<l; i++){
				this.thumbnails[i].addEventListener('click', this.onThumbClick.bind(this, i));
			}
			// note: there is a better way here using delegation event on thumbs container but the goal was to use the minimum amount of JavaScript
		},

		attachNavEvents: function() {

			// previous button
			this.navPrev.addEventListener('click', function() {
				this.active--;
				if(this.active < 0){
					this.active = this.thumbnails.length-1;
				}
				this.toElement(this.active);
			}.bind(this) );

			// next button
			this.navNext.addEventListener('click', function() {
				this.active++;
				if(this.active >= this.thumbnails.length){
					this.active = 0;
				}
				this.toElement(this.active);
			}.bind(this) );

		}

	};

	new JSONGallery('datas/gallery.json');


})(window, document, JSONGallery);