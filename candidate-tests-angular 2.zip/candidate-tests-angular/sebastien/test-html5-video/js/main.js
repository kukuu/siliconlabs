/*
---
name: HTML5Video
description: Instantiate controls for HTML5 Player
...
*/
var HTML5Video = HTML5Video || {};

(function(global, doc, object, undefined) {

	"use strict";

	// Seconds to time converter
	var secondsToTime = function(secs){

		var _sec_num = parseInt(secs, 10);
		var _hours   = Math.floor(_sec_num / 3600);
		var _minutes = Math.floor((_sec_num - (_hours * 3600)) / 60);
		var _seconds = _sec_num - (_hours * 3600) - (_minutes * 60);

		if (_hours   < 10) {_hours   = "0"+_hours;}
		if (_minutes < 10) {_minutes = "0"+_minutes;}
		if (_seconds < 10) {_seconds = "0"+_seconds;}

		return _hours+':'+_minutes+':'+_seconds;

	};

	var _removeControls = function() {
		_video.removeAttribute('controls');
	};

	/*
	 * Controls
	 */
	var _addControls = function() {
		_addPlay();
		_addPause();
		_addVolume();
	};

	var _addPlay = function() {
		doc.getElementById('play').addEventListener('click', function() {
			_video.play();
		});
	};

	var _addPause = function() {
		doc.getElementById('pause').addEventListener('click', function() {
			_video.pause();
		});
	};

	var _setVolume = function(volume) {
		_video.volume = _currentVolume;
	};

	var _addVolume = function() {

		_currentVolume = _video.volume;

		doc.getElementById('volume-down').addEventListener('click', function() {
			if(_currentVolume > 0){
				_currentVolume = Math.round( (_currentVolume - 0.2) * 100) / 100;
				_setVolume(_currentVolume);
			}
		});

		doc.getElementById('volume-up').addEventListener('click', function() {
			if(_currentVolume < 1){
				_currentVolume = Math.round( (_currentVolume + 0.2) * 100) / 100;
				_setVolume(_currentVolume);
			}
		});

	};

	/*
	 * Events
	 */
	var _addEvents =  function() {
		_addTimeUpdateEvent();
		_addMetaDataEvent();
		_addSeekChangeEvent();
	};

	var _addTimeUpdateEvent = function() {
		_video.addEventListener('timeupdate', function() {
			_updateBar(_video.currentTime, _video.duration);
			_timeleftElement.innerHTML = secondsToTime(_video.currentTime);
		});
	};

	var _addMetaDataEvent = function() {
		_video.addEventListener('loadedmetadata', function() {
			_durationElement.innerHTML = secondsToTime(_video.duration);
		});
	};

	var _addSeekChangeEvent = function() {
		_rangeElement.addEventListener('change', function() {
			var _seekSecs = _video.duration * (this.value / 100);
			_video.currentTime = _seekSecs;
		});
	};

	var _updateBar = function(timeleft, duration) {
		var _percent = Math.round( (timeleft / duration) * 100 );
		_rangeElement.value = _percent;
	};

	/*
	 * Initialization
	 */
	var _init = function(){

		_video = doc.getElementById('video-element');

		if(!_video) {
			return false;
		}

		_durationElement = doc.getElementById('video-duration');
		_timeleftElement = doc.getElementById('video-timeleft');
		_rangeElement    = doc.getElementById('video-range');

		_removeControls();
		_addControls();
		_addEvents();

	};

	var _video, _currentVolume, _durationElement, _timeleftElement, _rangeElement = null;

	_init();

})(window, document, HTML5Video);