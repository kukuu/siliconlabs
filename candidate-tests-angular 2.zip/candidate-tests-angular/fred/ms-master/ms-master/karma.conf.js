module.exports = function(config){
  config.set({

    basePath : './',

    frameworks : ['jasmine'],

    // list of files / patterns to load in the browser
    // you might need to add frameworks, for example:
    files : [
        'app/lib/angular/angular.js',
        'app/lib/angular-ui-router/angular-ui-router.js',
        'app/lib/angular-mocks/angular-mocks.js',
        'app/lib/angular-route/angular-route.js',
        'app/lib/angular-ui-utils/ui-utils.js',
        'app/lib/angular-resource/angular-resource.js',
        'app/lib/angular-animate/angular-animate.js',
        'app/lib/angular-bootstrap/ui-bootstrap-tpls.js',
        'app/lib/angular-socket-io/socket.js',
        'app/lib/angular-local-storage/angular-local-storage.js',

        'app/config/application.js',

        'app/modules/core/config/core.config.js',
        'app/modules/core/services/core.service.js',

        'app/modules/core/controllers/index.controller.js',

        'app/modules/users/tests/users.fixtures.js',
        'app/modules/users/tests/users.test.js',
    ],

    // list of files to exclude
    exclude : [
        'app/modules/navigation/controllers/header.controller.js'
    ],

    // test results reporter to use
    // possible values: 'dots', 'progress'
    // available reporters: https://npmjs.org/browse/keyword/karma-reporter
    reporters: ['spec'],
    // reporters: ['spec', 'teamcity'],

    // web server port
    port: 9876,

    // enable / disable colors in the output (reporters and logs)
    colors: true,


    // level of logging
    // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
    logLevel: config.LOG_INFO,

    // enable / disable watching file and executing tests whenever any file changes
    autoWatch : true,

    // start these browsers
    // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
    // or you can just use 'chrome'
    browsers : ['PhantomJS'],

    plugins : [
        'karma-chrome-launcher',
        'karma-firefox-launcher',
        'karma-phantomjs-launcher',
        'karma-jasmine',
        'karma-cli',
        'karma-junit-reporter',
        'karma-phantomjs-launcher',
        'karma-spec-reporter'
    ],

    junitReporter : {
      outputFile: 'test_out/unit.xml',
      suite: 'unit'
    },

    // Continuous Integration mode
    singleRun: true
  });
};

