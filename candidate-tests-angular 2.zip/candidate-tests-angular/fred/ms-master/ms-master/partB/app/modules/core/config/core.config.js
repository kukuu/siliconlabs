'use strict';
ApplicationConfiguration.registerModule('msTest.core');