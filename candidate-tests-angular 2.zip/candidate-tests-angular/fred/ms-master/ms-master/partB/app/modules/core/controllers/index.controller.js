'use strict';
ApplicationConfiguration.registerModule('msTest.search');

angular.module('msTest.core').controller('cartController',
    ['$scope', 'coreService',
    function($scope, coreService) {

        $scope.price = {
            total:0
        };

        $scope.items = coreService.getItems();


        $scope.init = function() {
            coreService.init($scope);
        }

        $scope.remove = function(id) {
            coreService.remove($scope, id);
        }
}]);