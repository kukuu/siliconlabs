'use strict';

angular.module('msTest.core').factory('coreService',
    [function () {

            return {
                init: function ($scope) {
                    var items = $scope.items,
                        total =0;

                    for (var i in items ) {
                        items[i].total = items[i].quantity * items[i].price;
                        total +=  items[i].total;
                    }
                    $scope.price.total = total;
                },

                remove: function ($scope, id) {
                    var index = 0,
                        self = this;

                    for (var i in $scope.items ) {

                        if ($scope.items[i].uid == id) {
                            break;
                        }
                        index++;
                    }

                    $scope.items.splice(index, 1);
                    self.init($scope);
                },

                getItems: function () {
                   return [
                       {
                           "category": "Women",
                           "subcat": "Clothing",
                           "item": "Party wear - Front Leather Panelled Ponte Treggings",
                           "price": "159.00",
                           "quantity":6,
                           "uid": 1
                       },
                       {
                           "category": "Women",
                           "subcat": "Clothing",
                           "item": "Speziale Italian Cupro Draped Bodycon Dress",
                           "price": "89.00",
                           "quantity":3,
                           "uid": 2
                       },
                       {
                           "category": "Beauty",
                           "subcat": "Skincare",
                           "item": "Aptiva - Wine Elixir Night Cream",
                           "price": "79.00",
                           "quantity":2,
                           "uid": 3
                       },
                       {
                           "category": "Men",
                           "subcat": "Suits & Tailoring",
                           "item": "Sartorial – Slim Fit Luxury Pure Cotton Rib Striped Shirt",
                           "price": "39.50",
                           "quantity":10,
                           "uid": 4
                       },
                       {
                           "category": "Men",
                           "subcat": "Jeans",
                           "item": "Big & Tall Washed Look Bootleg Denim Jeanst",
                           "price": "25.00",
                           "quantity":1,
                           "uid": 5
                       }
                   ]
                }
            };
        }]);