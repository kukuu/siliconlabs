# m&s coding
Then you can start your own development web server to serve static files from a folder by running:

http-server -a localhost -p 3000 in the root directory

run npm install in root/partB

https://mighty-hollows-1693.herokuapp.com/partB/app/

https://mighty-hollows-1693.herokuapp.com/partA/

https://mighty-hollows-1693.herokuapp.com/partA/form.html
