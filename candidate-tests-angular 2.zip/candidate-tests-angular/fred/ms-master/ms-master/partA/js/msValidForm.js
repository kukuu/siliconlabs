(function (window, document, undefined) {

    function FormValidator(formName, fields) {
        this.errors = [];
        this.fields = {};
        this.form = document.forms[formName] || {};
        this.handlers = {};

        var field;
        for (var i = 0, fieldLength = fields.length; i < fieldLength; i++) {

            field = fields[i];

            if (field.name) {
                this.addField(field, field.name);
            }
        }

        this.form.onsubmit = (function (that) {
            return function (evt) {

                try {
                    that.validateForm(evt);
                } catch (e) {
                    return false;
                }
            };
        })(this);
    }

    FormValidator.prototype.addField = function (field, nameValue) {
        this.fields[nameValue] = {
            name: nameValue,
            rules: field.rules,
            id: null,
            element: null,
            type: null,
            value: null,
            errorMsg:  field.error
        };
    };

    FormValidator.prototype.validateForm = function (evt) {
        var valid = true;
        this.errors = [];

        for (var key in this.fields) {
            if (this.fields.hasOwnProperty(key)) {
                var field = this.fields[key] || {},
                    element = this.form[field.name];

                if (element && element !== undefined) {
                    field.id = element.id;
                    field.element = element;
                    field.type = element.type;
                    field.value = element.value;

                    this.validateField(field);
                }
            }
        }

        if (this.errors.length > 0) {
            if (evt && evt.preventDefault) {
                evt.preventDefault();
                this.logError();
                valid = false;
            }
        }

        return valid;
    };

    FormValidator.prototype.validateField = function (field) {
        var test = field.rules.exec(field.value);

        if (test === null) {
            this.errors.push(field);
        }
    };

    /**
     * could be injected as callback param
     */
    FormValidator.prototype.logError = function () {

        var errorString = '';

        var el = document.querySelector('div.error_box');
        for (var i = 0, errorLength = this.errors.length; i < errorLength; i++) {
            errorString += this.errors[i].errorMsg + '<br />';
        }

        el.innerHTML = errorString;
    };


    var validator = new FormValidator('ms_form', [
        {name: 'first_name', rules: /^[a-z0-9_\-]+$/i, error:'name wrong format on alpha numeric'},
        {name: 'email',
            rules: /^(?:[a-zA-Z0-9!#$%&_]{2,})+@([a-zA-Z0-9])(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9]{2,}(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
            error:'email wrong format'
        },
        {name: 'credit_card', rules: /^[0-9]{14,16}$/, error:'credit card should be a number between 14 16 figures'},
        {name: 'security', rules: /^[0-9]{3}$/, error:'security should be a number 3 figures'}
    ]
    );

})(window, document);