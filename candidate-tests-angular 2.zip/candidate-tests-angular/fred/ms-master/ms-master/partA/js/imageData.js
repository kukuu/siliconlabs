

function imageDecorator(src, options) {

    if (options && typeof options == 'object') {
        this.setOptions(options);
    }

    this.src = src;
    this.image = new Image();
}

imageDecorator.prototype = {
    constructor: imageDecorator,
    options: {
        onProgress: function() {},
        onError: function() {},
        onComplete: function() {}
    },

    load: function (preloader) {
        this.errorHandle(preloader);
        this.loadHandle(preloader);
        this.image.src = this.src;
    },

    errorHandle: function (preloader) {
        var self = this,
            src = this.src,
            o = this.options,
            image = this.image;

        image.onerror = image.onabort = function () {
            this.onerror = this.onabort = this.onload = null; //this === image

            preloader.errors.push(src);

            if(o.onError) {
                o.onError.call(self, src);
            }

            preloader.checkProgress();
        }
    },

    loadHandle: function (preloader) {
        var self =this,
            src = this.src,
            o = this.options,
            image = this.image;

        image.onload = function () {
            this.onerror = this.onabort = this.onload = null; //this === image

            preloader.completed.push(src);

            if(o.onProgress) {
                o.onProgress.call(self, src);
            }

            preloader.checkProgress();
        };
    },

    setOptions: function (options) {
        var o = this.options,
            key;

        for (key in options) {
            if (options.hasOwnProperty(key)) {
                o[key] = options[key]
            }
        }

        return this;
    }
};

function preLoader(srcs) {

    return {

        queue: [],
        completed: [],
        errors: [],
        hasEnded: false,

        init: function () {
            this.buildQueue(srcs);

            if (this.queue.length) {
                this.processQueue();
            }
        },

        processQueue: function () {
            this.completed = [];
            this.errors = [];

            for (var i = 0, len = this.queue.length; i < len; ++i) {

                this.queue[i].load(this);
            }
        },

        buildQueue: function(srcs){
            for (var i = 0, len = srcs.length; i < len; ++i) {
                this.queue.push(new imageDecorator(srcs[i]));
            }
        },

        checkProgress: function() {
            var args = [],
                o = this.options;

            if (this.completed.length + this.errors.length === this.queue.length) {
                this.hasEnded = true;
            }
        }
    };
}

function thumbMngr() {
    var currentThumb = 0;
    return {
        init: function() {
            var thumbCtnr = document.querySelector('div.thumbs'),
                btnNext = document.querySelector('button#next'),
                self = this;

            thumbCtnr.addEventListener('click', function(e) {
                var thumb = e.target;
                if (e && e.preventDefault) {
                    e.preventDefault();
                }
                self.onPicSwitch.call(self, thumb);

            }, false);

            btnNext.addEventListener('click', function(e) {
                self.onClickNext.apply(self);

            }, false);
        },

        getThumbIndex: function(el) {
            var elementList = document.querySelectorAll('div.thumbs img'),
                currentSrc,
                targetSrc = el.parentNode.getAttribute("href"),
                ln = elementList.length;

            targetSrc.replace(/\?(video)=(.*)/, '');
            for(var i=0;i < ln; i++) {
                currentSrc = elementList[i].parentNode.getAttribute("href");
                if(currentSrc == targetSrc) {
                    break;
                }
            }
            return i;
        },

        onPicSwitch: function(el) {
            var largeImg = document.querySelector('img#largeImg'),
                parentEl = el.parentNode,
                video = document.querySelector('video'),
                test,
                targetSrc = parentEl.getAttribute("href");

            largeImg.setAttribute('class','');
            video.setAttribute('class','hidden');

            currentThumb = this.getThumbIndex(el);

            test = /\?(video)=(.*)/.exec(targetSrc);
            if (test !== null) {
                video.setAttribute('class','');
                largeImg.setAttribute('class','hidden');

                if(test.length == 3) {
                    var vid = toSource(video,test[2]);
                    vid.play();
                }
            } else {
                video.pause();
            }

            largeImg.setAttribute("src", targetSrc);
        },

        onClickNext: function() {
            currentThumb++;
            var elementList = document.querySelectorAll('div.thumbs img'),
                ln = elementList.length;
                if (currentThumb == ln) {
                    currentThumb = 0;
                }
                this.onPicSwitch(elementList[currentThumb]);
        }
    }
}

function toSource(video, src) {
    var source = document.createElement('source');

    source.src = src;
    source.type = 'video/ogg';

    document.body.appendChild(video);
    video.appendChild(source);

    return video;
}


var srcs = [
    'images/car1-lg.jpg',
    'images/car2-lg.jpg',
    'images/car3-lg.jpg',
    'images/car4-lg.jpg'
];

var imgLoader = preLoader(srcs);
imgLoader.init();

var gallery = thumbMngr();
gallery.init();



