var currency = {
    'USD': '$', // US Dollar
    'EUR': '€', // Euro
    'GBP': '£', // British Pound Sterling
    'INR': '₹', // Indian Rupee
    'JPY': '¥', // Japanese Yen
    'GH': '₵', // Ghanaian Cedi
    'THB': '฿' // Thai Baht
};

var rates = {
    "GBP": 3.673123,
        "USD": 58.964166,
        "EUR": 128.575701,
        "GBP": 1,
        "INR": 100,
        "JPY": 12.15316,
        "GH": 5252.024745,
        "THB": 7.270803
};

function fx(baseFx, rates, currency) {

    return {
        fxBase: baseFx,
        rates: rates,
        currency: currency,

        translate: function(input, to) {
            var matches = this.fxExtract(input),
                output,
                newText,
                newValue;

            newValue = this.convert(matches.val, to, matches.fx);
            newValue = parseFloat(Math.round(newValue * 100) / 100).toFixed(2);

            newText = this.currency[to] + newValue;
            output = input.replace(matches.txt, newText);

            return output;
        },

        fxExtract: function(input) {
            var matches,
                pattern = /([0-9\.]+)\s(\w+)/g,
                output = null;

            if ( typeof input === "string" ) {
                matches = pattern.exec(input);
                if (Array.isArray(matches) && matches.length === 3) {
                    output = {
                        txt: matches[0],
                        val: matches[1],
                        fx: matches[2]
                   };
                }
            }

            return output;
        },

        convert: function(val, to, from) {
            if( !from || !to ) {
                throw new Error('wrong format options for conversions');
            }

            return parseFloat(val) * this.getRate( to, from );
        },

        getRate: function (to, from) {
            var self = this,
                rates = this.rates;

            rates[this.fxBase] = 1; //this must be

            if ( !rates[to] || !rates[from] ) throw "fx error";

            if ( from === this.fxBase ) {
                return rates[to];

            } else if ( to === this.fxBase ) {
                return 1 / rates[from];
            }

            return rates[to] * (1 / rates[from]);
        },

        greetings: function() {
            var currentdate = new Date(),
                output = 'Hello';

            if ( currentdate.getHours() < 12 ) {
                output = "Good Morning!";
            } else if ( currentdate.getHours() >= 12 && currentdate.getHours() <= 17 ) {
                output = "Good Afternoon!";
            } else if ( currentdate.getHours() > 17 && currentdate.getHours() <= 24 ) {
                output = "Good Evening!";
            } else {
                output = "I'm not sure what time it is!";
            }

            return output;
        }
    }
}

var source = document.querySelector('div.original'),
    target = document.querySelector('div.translated');

var ukMoney = fx("GBP", rates, currency),
    str = ukMoney.translate(source.innerHTML, "GBP");

str = ukMoney.greetings() + ' ' + str;
target.innerHTML = str;



