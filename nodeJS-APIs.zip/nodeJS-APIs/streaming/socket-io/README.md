# Building real time applications with react and socket.io using nodejs

## To start the with this, follow the below steps

Go into the this above directory, and through command window / terminal, 

###### run : npm install 

With package.json, npm install all the dependencies required

###### run : node server

Now npm will start server at port 9090.

Now open two windows on http://localhost:9090/

type your text and you will see the broadcast on to the second page, 
you type text in the text box of second page, you will see the broadcast on to the first page.

Socket.io helps to brodcast on the go quickly.

![Alt text](https://raw.githubusercontent.com/amir-saeed/nodejs/master/Building-realtime-apps-with-react-socket-and-node/tutorials.png?raw=true "Title")


