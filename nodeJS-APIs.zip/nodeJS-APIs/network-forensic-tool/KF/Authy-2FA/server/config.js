module.exports = {
    PORT: process.env.SIMPLE_DEMO_PORT,
    API_KEY: process.env.DEMO_AUTHY_API_KEY,
    //SECRET: "SUPERSECRETSECRET"
    SECRET: "P7yyazbnl8k1VHdckdEYBiKk5V5mWwzh"
};