Embedded Apache ActiveMQ broker with STOMP over Websockets connector 

https://dzone.com/articles/easy-messaging-stomp-over
