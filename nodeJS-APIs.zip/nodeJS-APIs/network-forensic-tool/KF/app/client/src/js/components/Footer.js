import React from "react";
class Footer extends React.Component {
  render() {
    return (
      <footer>
        <div className="container">
          <div class="navbar navbar-inner  navbar-fixed-bottom">
            <p class="muted credit">Copyright @2017 - Kingfisher</p>
          </div>
        </div>
      </footer>
    );
  }
}

export default Footer;