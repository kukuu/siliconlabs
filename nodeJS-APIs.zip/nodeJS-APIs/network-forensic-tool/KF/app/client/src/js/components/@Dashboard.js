import React from "react";

class Dashboard extends React.Component {
    render() {
        return (
            <div className="container custom-body">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 className="card-heading">Kingfisher</h1>
                        <h3>INTELLIGENT NETWORK SECURITY</h3>
                        <div class="well text-center">
                            <p>Dashboard. You have </p>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Dashboard;
